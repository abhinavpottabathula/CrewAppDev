//
//  ImageArea.swift
//  Pic
//
//  Created by Shreyas Patankar on 2/5/16.
//  Copyright © 2016 Shreyas Patankar. All rights reserved.
//

import UIKit

class ImageArea: UICollectionViewCell {
    //An image in the grid of images
    @IBOutlet weak var image: UIImageView!
    
}
